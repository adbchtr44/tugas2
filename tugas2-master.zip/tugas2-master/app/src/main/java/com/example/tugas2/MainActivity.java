package com.example.tugas2;

import android.content.Intent;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.widget.Toast;

import com.example.tugas2.AdapterPahlawan;
import com.example.tugas2.DataPahlawan;
import com.example.tugas2.DetailActivity;
import com.example.tugas2.ModelPahlawan;
import com.example.tugas2.R;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private RecyclerView rvPahlawan;
    private ArrayList<ModelPahlawan> listPahlawan = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        rvPahlawan = findViewById(R.id.rv_pahlawan);
        rvPahlawan.setHasFixedSize(true);
        listPahlawan.addAll(DataPahlawan.getListData());

        recyclerView();
    }

    private void recyclerView() {
        rvPahlawan.setLayoutManager(new LinearLayoutManager(this));
        final AdapterPahlawan adapterPahlawan = new AdapterPahlawan(this);
        adapterPahlawan.setListPahlawan(listPahlawan);
        rvPahlawan.setAdapter(adapterPahlawan);

        adapterPahlawan.setOnItemClickCallback(new AdapterPahlawan.OnItemClickCallback() {
            @Override
            public void onItemClicked(ModelPahlawan pahlawan) {
                Toast.makeText(MainActivity.this, "Memilih "+pahlawan.getHeroName(),Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(MainActivity.this, DetailActivity.class);
                intent.putExtra(DetailActivity.EXTRA_DATA,pahlawan);
                startActivity(intent);
            }
        });
    }
}